# Project Report Guide — FinTrack

A chapter-by-chapter outline with draft content you can adapt for your project report. Replace bracketed items with your own details, and add your own screenshots (run `npm run seed` first so the pages have data).

---

## Title page / Certificate / Acknowledgement
Standard institution formats. Suggested title: **"FinTrack: A Web-Based Personal Finance and Budget Management System"**.

## Abstract (draft)
Managing personal finances is difficult without a single, reliable place to record income and spending. FinTrack is a full-stack web application that lets users record transactions, organise them into categories, set monthly budgets, and understand their habits through interactive charts. The system uses a React single-page frontend, a RESTful Node.js/Express backend and a SQLite relational database, secured with JWT authentication and bcrypt password hashing. Automated tests verify the API, and the application is containerised with Docker for easy deployment.

**Keywords:** personal finance, budget tracking, React, Node.js, REST API, SQLite, JWT.

## Chapter 1 — Introduction
- 1.1 Background: rise of digital money management; limits of paper notes and spreadsheets
- 1.2 Problem statement: users lack a simple, secure, visual way to track spending against budgets
- 1.3 Objectives
  1. Secure user registration and login
  2. Record, edit, search and filter income and expenses
  3. Category-wise monthly budgets with overspend alerts
  4. Visual dashboard (category split, six-month trend, savings rate)
  5. Export data to CSV
- 1.4 Scope and limitations (single currency — INR; manual entry; no bank integration)
- 1.5 Report organisation

## Chapter 2 — Literature survey / existing systems
Compare with spreadsheet tracking, Mint-style aggregators and open-source tools (e.g. Firefly III). Suggested comparison table:

| Aspect | Spreadsheet | Large finance apps | FinTrack |
|---|---|---|---|
| Setup effort | High | Low | Low |
| Budget progress feedback | Manual | Yes | Yes (live bars) |
| Data ownership | Full | Vendor-held | Full (self-hosted) |
| Customisable | Yes | Limited | Open source |

## Chapter 3 — System analysis
### 3.1 Functional requirements
| ID | Requirement |
|---|---|
| FR1 | Users can register and log in |
| FR2 | Users can create, read, update and delete transactions |
| FR3 | Users can manage custom categories |
| FR4 | Users can set a monthly budget per category |
| FR5 | System shows spent / remaining / status for each budget |
| FR6 | System shows monthly totals, savings rate and charts |
| FR7 | Users can search, filter and paginate transactions |
| FR8 | Users can export transactions as CSV |

### 3.2 Non-functional requirements
Security (hashed passwords, token auth, validation, rate limiting) · Usability (responsive, light/dark theme) · Performance (indexed queries, pagination) · Maintainability (modular code, tests) · Portability (Docker).

### 3.3 Feasibility
Technical (open-source stack, runs on a laptop), economic (no licensing cost), operational (simple UI).

### 3.4 Hardware / software requirements
Any computer with 4 GB RAM · Node.js 18+ · modern browser · VS Code · Git · (optional) Docker.

## Chapter 4 — System design
### 4.1 Architecture (three-tier)
Use the architecture diagram from `README.md` (Browser → Express API → SQLite).

### 4.2 Use cases
```mermaid
flowchart LR
    User((User)) --> UC1[Register / Login]
    User --> UC2[Manage transactions]
    User --> UC3[Manage categories]
    User --> UC4[Set budgets]
    User --> UC5[View dashboard]
    User --> UC6[Export CSV]
```

### 4.3 ER diagram and data dictionary
Use the ER diagram from `README.md`. Data dictionary:

**users**
| Column | Type | Constraint |
|---|---|---|
| id | INTEGER | Primary key, auto-increment |
| name | TEXT | Not null |
| email | TEXT | Unique, not null |
| password_hash | TEXT | Not null (bcrypt) |
| created_at | TEXT | Default current time |

**categories** — `id` PK · `user_id` FK→users · `name` · `color` · unique(`user_id`, `name`)

**transactions** — `id` PK · `user_id` FK→users · `category_id` FK→categories (SET NULL on delete) · `type` CHECK in (`income`,`expense`) · `amount` CHECK > 0 · `description` · `date` (YYYY-MM-DD)

**budgets** — `id` PK · `user_id` FK→users · `category_id` FK→categories · `month` (YYYY-MM) · `limit_amount` CHECK > 0 · unique(`user_id`, `category_id`, `month`)

### 4.4 Sequence diagram — adding a transaction
```mermaid
sequenceDiagram
    participant B as Browser (React)
    participant A as Express API
    participant D as SQLite
    B->>A: POST /api/transactions (Bearer JWT)
    A->>A: Verify JWT, validate body (Zod)
    A->>D: Check category belongs to user
    A->>D: INSERT transaction
    D-->>A: new row id
    A-->>B: 201 { transaction }
    B->>B: Refresh list and dashboard
```

### 4.5 Budget status logic
`spent` = sum of the month's expenses in that category. Status is **ok** below 80% of the limit, **warning** from 80% to 100%, and **over** above 100%.

## Chapter 5 — Implementation
Describe each module with a short code excerpt and screenshot:

| Module | Files |
|---|---|
| Authentication | `backend/src/routes/auth.js`, `middleware/auth.js`, `frontend/src/context/AuthContext.jsx` |
| Transactions | `routes/transactions.js`, `pages/Transactions.jsx`, `components/TransactionModal.jsx` |
| Categories | `routes/categories.js`, `pages/Categories.jsx` |
| Budgets | `routes/budgets.js`, `pages/Budgets.jsx` |
| Reports / dashboard | `routes/reports.js`, `pages/Dashboard.jsx` |
| Security | `app.js` (helmet, CORS, rate limiting), `middleware/validate.js` |

Technology justification: React for component-based UI; Express for a minimal REST layer; SQLite for zero-config relational storage; Zod for schema validation; Recharts for charts; Vite for fast builds.

## Chapter 6 — Testing
Automated API tests live in `backend/tests/api.test.js` (19 test cases, `npm test`). Mapping for your report:

| ID | Test case | Expected result |
|---|---|---|
| T1 | Health endpoint | 200 `{status:"ok"}` |
| T2 | Register with weak password / invalid email | 400 validation error |
| T3 | Register with duplicate email (case-insensitive) | 409 conflict |
| T4 | Login with correct / wrong password | 200 with token / 401 |
| T5 | Access protected route without or with bad token | 401 |
| T6 | `/auth/me` response | No password hash exposed |
| T7 | New account | Default categories seeded |
| T8 | Create / duplicate / delete category | 201 / 409 / 204 |
| T9 | Create income and expense | 201 with category name |
| T10 | Negative amount, bad date, bad type | 400 |
| T11 | List with filters and pagination | Correct totals and pages |
| T12 | Update and delete transaction | 200 / 204, then 404 on repeat |
| T13 | Another user's data (view, delete, use category) | Hidden / 404 / 400 |
| T14 | Budget upsert and status | spent, remaining, warning → over |
| T15 | Monthly summary | Correct income, expense, balance, savings rate |
| T16 | Six-month trend | Six months, zero-filled |
| T17 | Invalid month parameter | 400 |
| T18 | CSV export | `text/csv` with header and rows |
| T19 | CSV formula injection | Cells starting with `=` are neutralised |

Also include **manual UI test cases** (login flow, form validation messages, add/edit/delete, month switching, dark mode) with screenshots, and a test-results table once you've run the suite on your machine (record the date, the Node version and pass/fail counts).

## Chapter 7 — Results and discussion
Screenshots: login, dashboard, transactions with filters, add-transaction modal, budgets with progress bars, categories. Discuss how each objective was met and any limitations you observed.

## Chapter 8 — Conclusion and future scope
**Conclusion:** FinTrack delivers a secure, tested and deployable finance tracker covering the stated objectives.
**Future scope:** recurring transactions, multi-currency, receipt upload, email/SMS budget alerts, bank statement import, PostgreSQL for scaling, refresh tokens and httpOnly cookies, mobile app, ML-based spending forecasts.

## References (add the ones you actually use)
- React documentation — https://react.dev
- Express documentation — https://expressjs.com
- SQLite documentation — https://sqlite.org/docs.html
- JSON Web Tokens (RFC 7519) — https://datatracker.ietf.org/doc/html/rfc7519
- OWASP Cheat Sheet Series — https://cheatsheetseries.owasp.org
- Recharts — https://recharts.org

## Viva questions to prepare
1. Why JWT instead of server sessions? 2. How are passwords stored? 3. How do you stop one user reading another's data? 4. Why SQLite, and when would you move to PostgreSQL? 5. How does the budget status get calculated? 6. What does Zod validation protect against? 7. How would you scale this application?
