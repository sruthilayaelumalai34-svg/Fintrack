import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, getToken, setToken } from '../api.js';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());

  useEffect(() => {
    if (!getToken()) return;
    api.me().then((r) => setUser(r.user)).catch(() => setToken(null)).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onLogout = () => setUser(null);
    window.addEventListener('auth:logout', onLogout);
    return () => window.removeEventListener('auth:logout', onLogout);
  }, []);

  const finish = useCallback((res) => {
    setToken(res.token);
    setUser(res.user);
  }, []);

  const value = useMemo(
    () => ({
      user,
      loading,
      login: async (data) => finish(await api.login(data)),
      register: async (data) => finish(await api.register(data)),
      logout: () => { setToken(null); setUser(null); },
    }),
    [user, loading, finish]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
