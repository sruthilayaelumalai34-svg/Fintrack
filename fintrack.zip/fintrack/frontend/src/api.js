const BASE = import.meta.env.VITE_API_URL || '/api';
const TOKEN_KEY = 'fintrack_token';

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => (t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY));

export class ApiError extends Error {
  constructor(message, status, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

async function request(path, { method = 'GET', body, query, blob = false } = {}) {
  const qs = query
    ? '?' + new URLSearchParams(Object.entries(query).filter(([, v]) => v !== '' && v != null)).toString()
    : '';
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}${qs}`, { method, headers, body: body ? JSON.stringify(body) : undefined });

  if (res.status === 401 && token) {
    setToken(null);
    window.dispatchEvent(new Event('auth:logout'));
  }
  if (!res.ok) {
    let data = {};
    try { data = await res.json(); } catch { /* empty body */ }
    const detail = data.details?.map((d) => d.message).join('. ');
    throw new ApiError(detail || data.error || 'Something went wrong', res.status, data.details);
  }
  if (res.status === 204) return null;
  return blob ? res.blob() : res.json();
}

export const api = {
  register: (b) => request('/auth/register', { method: 'POST', body: b }),
  login: (b) => request('/auth/login', { method: 'POST', body: b }),
  me: () => request('/auth/me'),

  categories: () => request('/categories'),
  addCategory: (b) => request('/categories', { method: 'POST', body: b }),
  deleteCategory: (id) => request(`/categories/${id}`, { method: 'DELETE' }),

  transactions: (query) => request('/transactions', { query }),
  addTransaction: (b) => request('/transactions', { method: 'POST', body: b }),
  updateTransaction: (id, b) => request(`/transactions/${id}`, { method: 'PUT', body: b }),
  deleteTransaction: (id) => request(`/transactions/${id}`, { method: 'DELETE' }),
  exportCsv: (query) => request('/transactions/export.csv', { query, blob: true }),

  budgets: (month) => request('/budgets', { query: { month } }),
  saveBudget: (b) => request('/budgets', { method: 'POST', body: b }),
  deleteBudget: (id) => request(`/budgets/${id}`, { method: 'DELETE' }),

  summary: (month) => request('/reports/summary', { query: { month } }),
  trend: (month) => request('/reports/trend', { query: { month } }),
};
