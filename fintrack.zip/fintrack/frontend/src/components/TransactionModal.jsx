import { useState } from 'react';
import { api } from '../api.js';
import { today } from '../utils.js';
import { ErrorBanner } from './ui.jsx';

export default function TransactionModal({ transaction, categories, onClose, onSaved }) {
  const editing = !!transaction;
  const [form, setForm] = useState({
    type: transaction?.type ?? 'expense',
    amount: transaction?.amount ?? '',
    category_id: transaction?.category_id ?? '',
    description: transaction?.description ?? '',
    date: transaction?.date ?? today(),
  });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setError('');
    setSaving(true);
    const payload = { ...form, amount: Number(form.amount), category_id: form.category_id ? Number(form.category_id) : null };
    try {
      if (editing) await api.updateTransaction(transaction.id, payload);
      else await api.addTransaction(payload);
      onSaved();
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  }

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form className="modal card" onSubmit={submit}>
        <h2>{editing ? 'Edit transaction' : 'Add transaction'}</h2>
        <ErrorBanner message={error} />

        <div className="segmented" role="group" aria-label="Type">
          {['expense', 'income'].map((t) => (
            <button type="button" key={t} className={form.type === t ? `on ${t}` : ''} onClick={() => setForm((f) => ({ ...f, type: t }))}>
              {t === 'expense' ? 'Expense' : 'Income'}
            </button>
          ))}
        </div>

        <label>Amount (₹)
          <input type="number" min="0.01" step="0.01" required autoFocus value={form.amount} onChange={set('amount')} />
        </label>
        <label>Category
          <select value={form.category_id} onChange={set('category_id')}>
            <option value="">Uncategorised</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </label>
        <label>Description
          <input type="text" maxLength={200} value={form.description} onChange={set('description')} placeholder="e.g. Lunch with team" />
        </label>
        <label>Date
          <input type="date" required value={form.date} onChange={set('date')} />
        </label>

        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
        </div>
      </form>
    </div>
  );
}
