import { formatMoney } from '../utils.js';

export function StatCard({ label, value, tone, hint }) {
  return (
    <div className="card stat">
      <span className="muted">{label}</span>
      <strong className={`stat-value ${tone || ''}`}>{value}</strong>
      {hint && <span className="muted small">{hint}</span>}
    </div>
  );
}

export function ErrorBanner({ message }) {
  return message ? <div className="banner error" role="alert">{message}</div> : null;
}

export function EmptyState({ children }) {
  return <div className="empty">{children}</div>;
}

export function BudgetBar({ budget }) {
  const pct = Math.min(100, budget.percent_used);
  return (
    <div className="budget-row">
      <div className="budget-head">
        <span><i className="dot" style={{ background: budget.category_color }} />{budget.category_name}</span>
        <span className={`small ${budget.status === 'over' ? 'expense' : 'muted'}`}>
          {formatMoney(budget.spent)} / {formatMoney(budget.limit_amount)}
        </span>
      </div>
      <div className="bar" role="progressbar" aria-valuenow={budget.percent_used} aria-valuemin={0} aria-valuemax={100}>
        <div className={`bar-fill ${budget.status}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="small muted">
        {budget.status === 'over'
          ? `Over budget by ${formatMoney(-budget.remaining)}`
          : `${formatMoney(budget.remaining)} left (${budget.percent_used}% used)`}
      </span>
    </div>
  );
}
