import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const links = [
  ['/', 'Dashboard'],
  ['/transactions', 'Transactions'],
  ['/budgets', 'Budgets'],
  ['/categories', 'Categories'],
];

export default function Navbar() {
  const { user, logout } = useAuth();
  return (
    <header className="navbar">
      <div className="navbar-inner">
        <span className="brand">💰 FinTrack</span>
        <nav className="nav-links">
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="nav-user">
          <span className="muted hide-sm">{user.name}</span>
          <button className="btn btn-ghost" onClick={logout}>Log out</button>
        </div>
      </div>
    </header>
  );
}
