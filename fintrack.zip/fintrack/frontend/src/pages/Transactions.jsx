import { useCallback, useEffect, useState } from 'react';
import { api } from '../api.js';
import { downloadBlob, formatDate, formatMoneyExact } from '../utils.js';
import { EmptyState, ErrorBanner } from '../components/ui.jsx';
import TransactionModal from '../components/TransactionModal.jsx';

const EMPTY_FILTERS = { type: '', category_id: '', q: '', from: '', to: '' };

export default function Transactions() {
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [page, setPage] = useState(1);
  const [result, setResult] = useState(null);
  const [categories, setCategories] = useState([]);
  const [modal, setModal] = useState(null); // null | 'new' | transaction
  const [error, setError] = useState('');

  const load = useCallback(() => {
    setError('');
    api.transactions({ ...filters, page, limit: 10 }).then(setResult).catch((e) => setError(e.message));
  }, [filters, page]);

  useEffect(() => { api.categories().then((r) => setCategories(r.categories)).catch((e) => setError(e.message)); }, []);
  useEffect(load, [load]);

  const setFilter = (k) => (e) => {
    setPage(1);
    setFilters((f) => ({ ...f, [k]: e.target.value }));
  };

  async function remove(t) {
    if (!window.confirm(`Delete "${t.description || t.category_name || 'this transaction'}"?`)) return;
    try {
      await api.deleteTransaction(t.id);
      load();
    } catch (e) {
      setError(e.message);
    }
  }

  async function exportCsv() {
    try {
      downloadBlob(await api.exportCsv(filters), 'fintrack-transactions.csv');
    } catch (e) {
      setError(e.message);
    }
  }

  const tx = result?.transactions ?? [];
  const pg = result?.pagination;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Transactions</h1>
          <p className="muted">{pg ? `${pg.total} record${pg.total === 1 ? '' : 's'}` : 'Loading…'}</p>
        </div>
        <div className="row">
          <button className="btn btn-ghost" onClick={exportCsv}>Export CSV</button>
          <button className="btn btn-primary" onClick={() => setModal('new')}>+ Add</button>
        </div>
      </div>

      <div className="card filters">
        <input type="search" placeholder="Search description…" value={filters.q} onChange={setFilter('q')} />
        <select value={filters.type} onChange={setFilter('type')} aria-label="Type">
          <option value="">All types</option>
          <option value="expense">Expenses</option>
          <option value="income">Income</option>
        </select>
        <select value={filters.category_id} onChange={setFilter('category_id')} aria-label="Category">
          <option value="">All categories</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <input type="date" value={filters.from} onChange={setFilter('from')} aria-label="From date" />
        <input type="date" value={filters.to} onChange={setFilter('to')} aria-label="To date" />
        <button className="btn btn-ghost" onClick={() => { setFilters(EMPTY_FILTERS); setPage(1); }}>Reset</button>
      </div>

      <ErrorBanner message={error} />

      <div className="card table-wrap">
        {tx.length === 0 && result ? (
          <EmptyState>No transactions match. Try changing the filters or add a new one.</EmptyState>
        ) : (
          <table>
            <thead>
              <tr><th>Date</th><th>Description</th><th>Category</th><th className="right">Amount</th><th /></tr>
            </thead>
            <tbody>
              {tx.map((t) => (
                <tr key={t.id}>
                  <td>{formatDate(t.date)}</td>
                  <td>{t.description || <span className="muted">—</span>}</td>
                  <td>
                    {t.category_name ? <><i className="dot" style={{ background: t.category_color }} />{t.category_name}</> : <span className="muted">Uncategorised</span>}
                  </td>
                  <td className={`right ${t.type}`}>{t.type === 'income' ? '+' : '−'}{formatMoneyExact(t.amount)}</td>
                  <td className="right actions">
                    <button className="link" onClick={() => setModal(t)}>Edit</button>
                    <button className="link danger" onClick={() => remove(t)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {pg && pg.pages > 1 && (
        <div className="pager">
          <button className="btn btn-ghost" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>← Prev</button>
          <span className="muted">Page {pg.page} of {pg.pages}</span>
          <button className="btn btn-ghost" disabled={page >= pg.pages} onClick={() => setPage((p) => p + 1)}>Next →</button>
        </div>
      )}

      {modal && (
        <TransactionModal
          transaction={modal === 'new' ? null : modal}
          categories={categories}
          onClose={() => setModal(null)}
          onSaved={() => { setModal(null); load(); }}
        />
      )}
    </>
  );
}
