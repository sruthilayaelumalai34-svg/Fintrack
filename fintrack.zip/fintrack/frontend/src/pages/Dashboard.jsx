import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { api } from '../api.js';
import { currentMonth, formatDate, formatMoney, monthLabel } from '../utils.js';
import { BudgetBar, EmptyState, ErrorBanner, StatCard } from '../components/ui.jsx';

export default function Dashboard() {
  const [month, setMonth] = useState(currentMonth());
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setError('');
    Promise.all([
      api.summary(month),
      api.trend(month),
      api.budgets(month),
      api.transactions({ from: `${month}-01`, to: `${month}-31`, limit: 5 }),
    ])
      .then(([summary, trend, budgets, recent]) => {
        if (!cancelled) setData({ summary, trend: trend.trend, budgets: budgets.budgets, recent: recent.transactions });
      })
      .catch((e) => !cancelled && setError(e.message));
    return () => { cancelled = true; };
  }, [month]);

  const s = data?.summary;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Dashboard</h1>
          <p className="muted">Overview for {monthLabel(month)}</p>
        </div>
        <input type="month" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} aria-label="Select month" />
      </div>

      <ErrorBanner message={error} />
      {!data && !error && <p className="muted">Loading…</p>}

      {data && (
        <>
          <section className="grid stats">
            <StatCard label="Income" value={formatMoney(s.income)} tone="income" />
            <StatCard label="Expenses" value={formatMoney(s.expense)} tone="expense" />
            <StatCard label="Balance" value={formatMoney(s.balance)} tone={s.balance >= 0 ? 'income' : 'expense'} />
            <StatCard
              label="Savings rate"
              value={s.savings_rate == null ? '—' : `${s.savings_rate}%`}
              hint={s.savings_rate == null ? 'No income recorded' : 'of income saved'}
            />
          </section>

          <section className="grid two">
            <div className="card">
              <h2>Spending by category</h2>
              {s.by_category.length === 0 ? (
                <EmptyState>No expenses this month yet.</EmptyState>
              ) : (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={s.by_category} dataKey="total" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={2}>
                      {s.by_category.map((c) => <Cell key={c.name} fill={c.color} />)}
                    </Pie>
                    <Tooltip formatter={(v) => formatMoney(v)} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>

            <div className="card">
              <h2>Last 6 months</h2>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={data.trend.map((t) => ({ ...t, label: monthLabel(t.month, true) }))}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="label" />
                  <YAxis tickFormatter={(v) => (v >= 1000 ? `${v / 1000}k` : v)} width={45} />
                  <Tooltip formatter={(v) => formatMoney(v)} />
                  <Legend />
                  <Bar dataKey="income" name="Income" fill="#22c55e" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="expense" name="Expenses" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className="grid two">
            <div className="card">
              <div className="card-head">
                <h2>Budgets</h2>
                <Link to="/budgets">Manage</Link>
              </div>
              {data.budgets.length === 0 ? (
                <EmptyState>No budgets set for this month. <Link to="/budgets">Create one</Link>.</EmptyState>
              ) : (
                data.budgets.map((b) => <BudgetBar key={b.id} budget={b} />)
              )}
            </div>

            <div className="card">
              <div className="card-head">
                <h2>Recent transactions</h2>
                <Link to="/transactions">View all</Link>
              </div>
              {data.recent.length === 0 ? (
                <EmptyState>Nothing recorded yet.</EmptyState>
              ) : (
                <ul className="tx-list">
                  {data.recent.map((t) => (
                    <li key={t.id}>
                      <div>
                        <strong>{t.description || t.category_name || 'Transaction'}</strong>
                        <span className="small muted">{t.category_name || 'Uncategorised'} · {formatDate(t.date)}</span>
                      </div>
                      <span className={t.type}>{t.type === 'income' ? '+' : '−'}{formatMoney(t.amount)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>
        </>
      )}
    </>
  );
}
