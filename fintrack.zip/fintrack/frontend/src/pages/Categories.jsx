import { useCallback, useEffect, useState } from 'react';
import { api } from '../api.js';
import { EmptyState, ErrorBanner } from '../components/ui.jsx';

export default function Categories() {
  const [categories, setCategories] = useState(null);
  const [form, setForm] = useState({ name: '', color: '#6366f1' });
  const [error, setError] = useState('');

  const load = useCallback(() => {
    api.categories().then((r) => setCategories(r.categories)).catch((e) => setError(e.message));
  }, []);
  useEffect(load, [load]);

  async function add(e) {
    e.preventDefault();
    setError('');
    try {
      await api.addCategory(form);
      setForm({ name: '', color: form.color });
      load();
    } catch (err) {
      setError(err.status === 409 ? 'You already have a category with that name' : err.message);
    }
  }

  async function remove(c) {
    if (!window.confirm(`Delete "${c.name}"? Its transactions will become uncategorised and its budgets will be removed.`)) return;
    try {
      await api.deleteCategory(c.id);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Categories</h1>
          <p className="muted">Organise your transactions your way</p>
        </div>
      </div>

      <ErrorBanner message={error} />

      <form className="card inline-form" onSubmit={add}>
        <input required maxLength={40} placeholder="New category name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
        <input type="color" value={form.color} onChange={(e) => setForm((f) => ({ ...f, color: e.target.value }))} aria-label="Colour" />
        <button className="btn btn-primary">Add category</button>
      </form>

      <div className="card">
        {!categories ? (
          <p className="muted">Loading…</p>
        ) : categories.length === 0 ? (
          <EmptyState>No categories yet.</EmptyState>
        ) : (
          <ul className="cat-list">
            {categories.map((c) => (
              <li key={c.id}>
                <span><i className="dot" style={{ background: c.color }} />{c.name}</span>
                <button className="link danger" onClick={() => remove(c)}>Delete</button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
