import { useCallback, useEffect, useState } from 'react';
import { api } from '../api.js';
import { currentMonth, monthLabel } from '../utils.js';
import { BudgetBar, EmptyState, ErrorBanner } from '../components/ui.jsx';

export default function Budgets() {
  const [month, setMonth] = useState(currentMonth());
  const [budgets, setBudgets] = useState(null);
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({ category_id: '', limit_amount: '' });
  const [error, setError] = useState('');

  const load = useCallback(() => {
    api.budgets(month).then((r) => setBudgets(r.budgets)).catch((e) => setError(e.message));
  }, [month]);

  useEffect(() => { api.categories().then((r) => setCategories(r.categories)).catch((e) => setError(e.message)); }, []);
  useEffect(load, [load]);

  async function save(e) {
    e.preventDefault();
    setError('');
    try {
      await api.saveBudget({ category_id: Number(form.category_id), limit_amount: Number(form.limit_amount), month });
      setForm({ category_id: '', limit_amount: '' });
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function remove(id) {
    try {
      await api.deleteBudget(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Budgets</h1>
          <p className="muted">Monthly spending limits for {monthLabel(month)}</p>
        </div>
        <input type="month" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} aria-label="Select month" />
      </div>

      <ErrorBanner message={error} />

      <form className="card inline-form" onSubmit={save}>
        <select required value={form.category_id} onChange={(e) => setForm((f) => ({ ...f, category_id: e.target.value }))} aria-label="Category">
          <option value="">Choose category…</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <input
          type="number" min="1" step="1" required placeholder="Monthly limit (₹)"
          value={form.limit_amount} onChange={(e) => setForm((f) => ({ ...f, limit_amount: e.target.value }))}
        />
        <button className="btn btn-primary">Set budget</button>
      </form>
      <p className="small muted">Setting a budget for a category that already has one updates its limit.</p>

      <div className="card">
        {!budgets ? (
          <p className="muted">Loading…</p>
        ) : budgets.length === 0 ? (
          <EmptyState>No budgets for this month yet.</EmptyState>
        ) : (
          budgets.map((b) => (
            <div key={b.id} className="budget-item">
              <BudgetBar budget={b} />
              <button className="link danger" onClick={() => remove(b.id)}>Remove</button>
            </div>
          ))
        )}
      </div>
    </>
  );
}
