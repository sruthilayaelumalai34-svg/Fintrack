import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  email         TEXT    NOT NULL UNIQUE,
  password_hash TEXT    NOT NULL,
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name    TEXT    NOT NULL,
  color   TEXT    NOT NULL DEFAULT '#6366f1',
  UNIQUE (user_id, name)
);

CREATE TABLE IF NOT EXISTS transactions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  type        TEXT    NOT NULL CHECK (type IN ('income', 'expense')),
  amount      REAL    NOT NULL CHECK (amount > 0),
  description TEXT    NOT NULL DEFAULT '',
  date        TEXT    NOT NULL,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS budgets (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id  INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  month        TEXT    NOT NULL,
  limit_amount REAL    NOT NULL CHECK (limit_amount > 0),
  UNIQUE (user_id, category_id, month)
);

CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions (user_id, date);
CREATE INDEX IF NOT EXISTS idx_tx_user_cat  ON transactions (user_id, category_id);
CREATE INDEX IF NOT EXISTS idx_budget_user_month ON budgets (user_id, month);
`;

export function createDb(file = ':memory:') {
  if (file !== ':memory:') {
    fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  }
  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);
  return db;
}

export const DEFAULT_CATEGORIES = [
  ['Salary', '#22c55e'],
  ['Food & Dining', '#f97316'],
  ['Transport', '#3b82f6'],
  ['Rent & Utilities', '#a855f7'],
  ['Shopping', '#ec4899'],
  ['Health', '#ef4444'],
  ['Entertainment', '#eab308'],
  ['Education', '#14b8a6'],
  ['Other', '#64748b'],
];

export function seedDefaultCategories(db, userId) {
  const insert = db.prepare('INSERT OR IGNORE INTO categories (user_id, name, color) VALUES (?, ?, ?)');
  const run = db.transaction(() => {
    for (const [name, color] of DEFAULT_CATEGORIES) insert.run(userId, name, color);
  });
  run();
}
