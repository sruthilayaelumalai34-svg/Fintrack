import { ZodError } from 'zod';

// Wraps a zod schema; replaces req[source] with the parsed (coerced) value.
export const validate =
  (schema, source = 'body') =>
  (req, res, next) => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: result.error.issues.map((i) => ({ field: i.path.join('.'), message: i.message })),
      });
    }
    // req.query is a getter in Express 5, so store parsed data separately.
    req.valid = { ...(req.valid || {}), [source]: result.data };
    next();
  };

export function errorHandler(err, _req, res, _next) {
  if (err instanceof ZodError) {
    return res.status(400).json({ error: 'Validation failed' });
  }
  if (err?.code === 'SQLITE_CONSTRAINT_UNIQUE') {
    return res.status(409).json({ error: 'Already exists' });
  }
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
}
