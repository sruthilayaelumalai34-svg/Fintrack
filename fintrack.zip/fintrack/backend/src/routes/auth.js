import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { seedDefaultCategories } from '../db.js';
import { requireAuth, signToken } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const registerSchema = z.object({
  name: z.string().trim().min(2, 'Name must be at least 2 characters').max(60),
  email: z.string().trim().toLowerCase().email('Enter a valid email'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(72)
    .regex(/[A-Za-z]/, 'Password needs a letter')
    .regex(/\d/, 'Password needs a number'),
});

const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1),
});

export default function authRoutes(db) {
  const router = Router();

  router.post('/register', validate(registerSchema), (req, res) => {
    const { name, email, password } = req.valid.body;
    const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (exists) return res.status(409).json({ error: 'Email is already registered' });

    const hash = bcrypt.hashSync(password, 10);
    const info = db
      .prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
      .run(name, email, hash);
    seedDefaultCategories(db, info.lastInsertRowid);

    const user = { id: info.lastInsertRowid, name, email };
    res.status(201).json({ token: signToken(user), user });
  });

  router.post('/login', validate(loginSchema), (req, res) => {
    const { email, password } = req.valid.body;
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!row || !bcrypt.compareSync(password, row.password_hash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const user = { id: row.id, name: row.name, email: row.email };
    res.json({ token: signToken(user), user });
  });

  router.get('/me', requireAuth, (req, res) => {
    const user = db.prepare('SELECT id, name, email, created_at FROM users WHERE id = ?').get(req.user.id);
    if (!user) return res.status(401).json({ error: 'User no longer exists' });
    res.json({ user });
  });

  return router;
}
