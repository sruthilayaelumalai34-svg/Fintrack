import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validate.js';

const month = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, 'Month must be YYYY-MM');

const budgetSchema = z.object({
  category_id: z.coerce.number().int().positive(),
  month,
  limit_amount: z.coerce.number().positive('Limit must be greater than 0').max(1e9),
});

const listSchema = z.object({ month });

export default function budgetRoutes(db) {
  const router = Router();

  router.get('/', validate(listSchema, 'query'), (req, res) => {
    const rows = db
      .prepare(
        `SELECT b.id, b.category_id, b.month, b.limit_amount,
                c.name AS category_name, c.color AS category_color,
                COALESCE((
                  SELECT SUM(t.amount) FROM transactions t
                  WHERE t.user_id = b.user_id AND t.category_id = b.category_id
                    AND t.type = 'expense' AND substr(t.date, 1, 7) = b.month
                ), 0) AS spent
         FROM budgets b JOIN categories c ON c.id = b.category_id
         WHERE b.user_id = ? AND b.month = ?
         ORDER BY c.name`
      )
      .all(req.user.id, req.valid.query.month);

    const budgets = rows.map((r) => ({
      ...r,
      remaining: r.limit_amount - r.spent,
      percent_used: Math.round((r.spent / r.limit_amount) * 100),
      status: r.spent > r.limit_amount ? 'over' : r.spent >= r.limit_amount * 0.8 ? 'warning' : 'ok',
    }));
    res.json({ budgets });
  });

  // Create or update (upsert) the budget for a category + month
  router.post('/', validate(budgetSchema), (req, res) => {
    const b = req.valid.body;
    const owns = db.prepare('SELECT 1 FROM categories WHERE id = ? AND user_id = ?').get(b.category_id, req.user.id);
    if (!owns) return res.status(400).json({ error: 'Unknown category' });
    db.prepare(
      `INSERT INTO budgets (user_id, category_id, month, limit_amount) VALUES (?, ?, ?, ?)
       ON CONFLICT (user_id, category_id, month) DO UPDATE SET limit_amount = excluded.limit_amount`
    ).run(req.user.id, b.category_id, b.month, b.limit_amount);
    res.status(201).json({ ok: true });
  });

  router.delete('/:id', (req, res) => {
    const info = db
      .prepare('DELETE FROM budgets WHERE id = ? AND user_id = ?')
      .run(Number(req.params.id), req.user.id);
    if (!info.changes) return res.status(404).json({ error: 'Budget not found' });
    res.status(204).end();
  });

  return router;
}
