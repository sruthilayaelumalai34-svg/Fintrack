import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validate.js';

const querySchema = z.object({
  month: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, 'Month must be YYYY-MM'),
});

// Returns the last `n` month keys (YYYY-MM) ending at `end`, oldest first.
function lastMonths(end, n) {
  const [y, m] = end.split('-').map(Number);
  const out = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(y, m - 1 - i, 1));
    out.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`);
  }
  return out;
}

export default function reportRoutes(db) {
  const router = Router();

  // Totals + category breakdown for one month
  router.get('/summary', validate(querySchema, 'query'), (req, res) => {
    const { month } = req.valid.query;
    const uid = req.user.id;

    const totals = db
      .prepare(
        `SELECT
           COALESCE(SUM(CASE WHEN type = 'income'  THEN amount END), 0) AS income,
           COALESCE(SUM(CASE WHEN type = 'expense' THEN amount END), 0) AS expense,
           COUNT(*) AS count
         FROM transactions WHERE user_id = ? AND substr(date, 1, 7) = ?`
      )
      .get(uid, month);

    const byCategory = db
      .prepare(
        `SELECT COALESCE(c.name, 'Uncategorised') AS name, COALESCE(c.color, '#94a3b8') AS color,
                SUM(t.amount) AS total
         FROM transactions t LEFT JOIN categories c ON c.id = t.category_id
         WHERE t.user_id = ? AND t.type = 'expense' AND substr(t.date, 1, 7) = ?
         GROUP BY t.category_id ORDER BY total DESC`
      )
      .all(uid, month);

    const savingsRate = totals.income > 0 ? Math.round(((totals.income - totals.expense) / totals.income) * 100) : null;

    res.json({
      month,
      income: totals.income,
      expense: totals.expense,
      balance: totals.income - totals.expense,
      savings_rate: savingsRate,
      transaction_count: totals.count,
      by_category: byCategory,
    });
  });

  // Six-month income vs expense trend
  router.get('/trend', validate(querySchema, 'query'), (req, res) => {
    const months = lastMonths(req.valid.query.month, 6);
    const rows = db
      .prepare(
        `SELECT substr(date, 1, 7) AS month, type, SUM(amount) AS total
         FROM transactions
         WHERE user_id = ? AND substr(date, 1, 7) BETWEEN ? AND ?
         GROUP BY month, type`
      )
      .all(req.user.id, months[0], months[months.length - 1]);

    const trend = months.map((m) => ({
      month: m,
      income: rows.find((r) => r.month === m && r.type === 'income')?.total ?? 0,
      expense: rows.find((r) => r.month === m && r.type === 'expense')?.total ?? 0,
    }));
    res.json({ trend });
  });

  return router;
}
