import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validate.js';

const categorySchema = z.object({
  name: z.string().trim().min(1, 'Name is required').max(40),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Color must be a hex value like #22c55e').default('#6366f1'),
});

export default function categoryRoutes(db) {
  const router = Router();

  router.get('/', (req, res) => {
    const rows = db
      .prepare('SELECT id, name, color FROM categories WHERE user_id = ? ORDER BY name')
      .all(req.user.id);
    res.json({ categories: rows });
  });

  router.post('/', validate(categorySchema), (req, res) => {
    const { name, color } = req.valid.body;
    const info = db
      .prepare('INSERT INTO categories (user_id, name, color) VALUES (?, ?, ?)')
      .run(req.user.id, name, color);
    res.status(201).json({ category: { id: info.lastInsertRowid, name, color } });
  });

  router.delete('/:id', (req, res) => {
    const info = db
      .prepare('DELETE FROM categories WHERE id = ? AND user_id = ?')
      .run(Number(req.params.id), req.user.id);
    if (!info.changes) return res.status(404).json({ error: 'Category not found' });
    res.status(204).end();
  });

  return router;
}
