import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validate.js';

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be YYYY-MM-DD');

const txSchema = z.object({
  type: z.enum(['income', 'expense']),
  amount: z.coerce.number().positive('Amount must be greater than 0').max(1e9),
  category_id: z.coerce.number().int().positive().nullable().optional(),
  description: z.string().trim().max(200).default(''),
  date: isoDate,
});

const listSchema = z.object({
  type: z.enum(['income', 'expense']).optional(),
  category_id: z.coerce.number().int().positive().optional(),
  from: isoDate.optional(),
  to: isoDate.optional(),
  q: z.string().trim().max(100).optional(),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(10),
});

function buildFilter(userId, f) {
  const where = ['t.user_id = ?'];
  const params = [userId];
  if (f.type) { where.push('t.type = ?'); params.push(f.type); }
  if (f.category_id) { where.push('t.category_id = ?'); params.push(f.category_id); }
  if (f.from) { where.push('t.date >= ?'); params.push(f.from); }
  if (f.to) { where.push('t.date <= ?'); params.push(f.to); }
  if (f.q) { where.push('t.description LIKE ?'); params.push(`%${f.q}%`); }
  return { clause: where.join(' AND '), params };
}

const SELECT = `
  SELECT t.id, t.type, t.amount, t.description, t.date, t.category_id,
         c.name AS category_name, c.color AS category_color
  FROM transactions t
  LEFT JOIN categories c ON c.id = t.category_id`;

export default function transactionRoutes(db) {
  const router = Router();

  const ownsCategory = (userId, categoryId) =>
    !categoryId || !!db.prepare('SELECT 1 FROM categories WHERE id = ? AND user_id = ?').get(categoryId, userId);

  router.get('/', validate(listSchema, 'query'), (req, res) => {
    const f = req.valid.query;
    const { clause, params } = buildFilter(req.user.id, f);
    const total = db.prepare(`SELECT COUNT(*) AS n FROM transactions t WHERE ${clause}`).get(...params).n;
    const rows = db
      .prepare(`${SELECT} WHERE ${clause} ORDER BY t.date DESC, t.id DESC LIMIT ? OFFSET ?`)
      .all(...params, f.limit, (f.page - 1) * f.limit);
    res.json({
      transactions: rows,
      pagination: { page: f.page, limit: f.limit, total, pages: Math.max(1, Math.ceil(total / f.limit)) },
    });
  });

  router.get('/export.csv', validate(listSchema.partial(), 'query'), (req, res) => {
    const { clause, params } = buildFilter(req.user.id, req.valid.query);
    const rows = db.prepare(`${SELECT} WHERE ${clause} ORDER BY t.date DESC, t.id DESC`).all(...params);
    const esc = (v) => {
      let s = String(v ?? '');
      // Neutralise spreadsheet formula injection
      if (/^[=+\-@]/.test(s)) s = `'${s}`;
      return `"${s.replace(/"/g, '""')}"`;
    };
    const lines = ['Date,Type,Category,Description,Amount'];
    for (const r of rows) {
      lines.push([r.date, r.type, r.category_name, r.description, r.amount.toFixed(2)].map(esc).join(','));
    }
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="fintrack-transactions.csv"');
    res.send(lines.join('\n'));
  });

  router.post('/', validate(txSchema), (req, res) => {
    const b = req.valid.body;
    if (!ownsCategory(req.user.id, b.category_id)) return res.status(400).json({ error: 'Unknown category' });
    const info = db
      .prepare('INSERT INTO transactions (user_id, category_id, type, amount, description, date) VALUES (?, ?, ?, ?, ?, ?)')
      .run(req.user.id, b.category_id ?? null, b.type, b.amount, b.description, b.date);
    const row = db.prepare(`${SELECT} WHERE t.id = ?`).get(info.lastInsertRowid);
    res.status(201).json({ transaction: row });
  });

  router.put('/:id', validate(txSchema), (req, res) => {
    const b = req.valid.body;
    if (!ownsCategory(req.user.id, b.category_id)) return res.status(400).json({ error: 'Unknown category' });
    const id = Number(req.params.id);
    const info = db
      .prepare('UPDATE transactions SET category_id = ?, type = ?, amount = ?, description = ?, date = ? WHERE id = ? AND user_id = ?')
      .run(b.category_id ?? null, b.type, b.amount, b.description, b.date, id, req.user.id);
    if (!info.changes) return res.status(404).json({ error: 'Transaction not found' });
    res.json({ transaction: db.prepare(`${SELECT} WHERE t.id = ?`).get(id) });
  });

  router.delete('/:id', (req, res) => {
    const info = db
      .prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?')
      .run(Number(req.params.id), req.user.id);
    if (!info.changes) return res.status(404).json({ error: 'Transaction not found' });
    res.status(204).end();
  });

  return router;
}
