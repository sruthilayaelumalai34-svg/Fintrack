import { config } from './config.js';
import { createDb } from './db.js';
import { createApp } from './app.js';

const db = createDb(config.dbPath);
const app = createApp(db, { logging: !config.isProd });

const server = app.listen(config.port, () => {
  console.log(`FinTrack API listening on http://localhost:${config.port}`);
});

function shutdown() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
