// Creates a demo account with ~4 months of realistic data (handy for screenshots in the report).
// Usage: npm run seed   ->  login with demo@fintrack.dev / Demo@1234
import bcrypt from 'bcryptjs';
import { config } from '../src/config.js';
import { createDb, seedDefaultCategories } from '../src/db.js';

const db = createDb(config.dbPath);
const email = 'demo@fintrack.dev';

db.prepare('DELETE FROM users WHERE email = ?').run(email);
const uid = db
  .prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
  .run('Demo User', email, bcrypt.hashSync('Demo@1234', 10)).lastInsertRowid;
seedDefaultCategories(db, uid);

const cat = Object.fromEntries(
  db.prepare('SELECT id, name FROM categories WHERE user_id = ?').all(uid).map((c) => [c.name, c.id])
);

const insertTx = db.prepare(
  'INSERT INTO transactions (user_id, category_id, type, amount, description, date) VALUES (?, ?, ?, ?, ?, ?)'
);
const insertBudget = db.prepare(
  'INSERT INTO budgets (user_id, category_id, month, limit_amount) VALUES (?, ?, ?, ?)'
);

// Deterministic pseudo-random so every seed run looks the same
let s = 42;
const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
const between = (a, b) => Math.round(a + rnd() * (b - a));

const now = new Date();
const run = db.transaction(() => {
  for (let back = 3; back >= 0; back--) {
    const d = new Date(now.getFullYear(), now.getMonth() - back, 1);
    const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const day = (n) => `${ym}-${String(n).padStart(2, '0')}`;

    insertTx.run(uid, cat['Salary'], 'income', 65000, 'Monthly salary', day(1));
    if (back % 2 === 0) insertTx.run(uid, cat['Other'], 'income', between(3000, 9000), 'Freelance project', day(15));

    insertTx.run(uid, cat['Rent & Utilities'], 'expense', 18000, 'House rent', day(2));
    insertTx.run(uid, cat['Rent & Utilities'], 'expense', between(1200, 2200), 'Electricity & internet', day(8));
    for (let i = 0; i < 6; i++) {
      insertTx.run(uid, cat['Food & Dining'], 'expense', between(150, 1100), 'Groceries / eating out', day(between(3, 27)));
    }
    for (let i = 0; i < 4; i++) {
      insertTx.run(uid, cat['Transport'], 'expense', between(80, 700), 'Cab / fuel / metro', day(between(3, 27)));
    }
    insertTx.run(uid, cat['Shopping'], 'expense', between(1500, 5500), 'Clothes & accessories', day(between(5, 25)));
    insertTx.run(uid, cat['Entertainment'], 'expense', between(300, 1500), 'Movies & subscriptions', day(between(5, 25)));
    if (back % 2 === 1) insertTx.run(uid, cat['Health'], 'expense', between(500, 3000), 'Pharmacy / check-up', day(between(5, 25)));

    insertBudget.run(uid, cat['Food & Dining'], ym, 6000);
    insertBudget.run(uid, cat['Transport'], ym, 2500);
    insertBudget.run(uid, cat['Shopping'], ym, 4000);
    insertBudget.run(uid, cat['Entertainment'], ym, 1500);
  }
});
run();

console.log(`Seeded demo user -> ${email} / Demo@1234`);
db.close();
