import { test, describe, before } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';

process.env.NODE_ENV = 'test';
const { createDb } = await import('../src/db.js');
const { createApp } = await import('../src/app.js');

const app = createApp(createDb(':memory:'));
const api = () => request(app);

const MONTH = '2026-03';
let alice; // { token, user }
let bob;

async function register(name, email) {
  const res = await api().post('/api/auth/register').send({ name, email, password: 'Passw0rd!' });
  assert.equal(res.status, 201);
  return res.body;
}
const auth = (u) => ({ Authorization: `Bearer ${u.token}` });

before(async () => {
  alice = await register('Alice', 'alice@example.com');
  bob = await register('Bob', 'bob@example.com');
});

describe('Health & auth', () => {
  test('health endpoint responds', async () => {
    const res = await api().get('/api/health');
    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'ok');
  });

  test('register rejects weak password and bad email', async () => {
    const weak = await api().post('/api/auth/register').send({ name: 'Eve', email: 'eve@example.com', password: 'short' });
    assert.equal(weak.status, 400);
    const bad = await api().post('/api/auth/register').send({ name: 'Eve', email: 'nope', password: 'Passw0rd!' });
    assert.equal(bad.status, 400);
  });

  test('duplicate email is rejected', async () => {
    const res = await api().post('/api/auth/register').send({ name: 'A2', email: 'ALICE@example.com', password: 'Passw0rd!' });
    assert.equal(res.status, 409);
  });

  test('login succeeds with correct credentials and fails otherwise', async () => {
    const ok = await api().post('/api/auth/login').send({ email: 'alice@example.com', password: 'Passw0rd!' });
    assert.equal(ok.status, 200);
    assert.ok(ok.body.token);
    const bad = await api().post('/api/auth/login').send({ email: 'alice@example.com', password: 'wrong-pass1' });
    assert.equal(bad.status, 401);
  });

  test('protected routes require a valid token', async () => {
    assert.equal((await api().get('/api/transactions')).status, 401);
    assert.equal((await api().get('/api/transactions').set('Authorization', 'Bearer garbage')).status, 401);
    const me = await api().get('/api/auth/me').set(auth(alice));
    assert.equal(me.status, 200);
    assert.equal(me.body.user.email, 'alice@example.com');
  });

  test('password hash is never returned', async () => {
    const me = await api().get('/api/auth/me').set(auth(alice));
    assert.equal(me.body.user.password_hash, undefined);
  });
});

describe('Categories', () => {
  test('default categories are seeded on registration', async () => {
    const res = await api().get('/api/categories').set(auth(alice));
    assert.equal(res.status, 200);
    assert.ok(res.body.categories.length >= 9);
  });

  test('can create and delete a custom category; duplicates are rejected', async () => {
    const created = await api().post('/api/categories').set(auth(alice)).send({ name: 'Pets', color: '#123abc' });
    assert.equal(created.status, 201);
    const dup = await api().post('/api/categories').set(auth(alice)).send({ name: 'Pets' });
    assert.equal(dup.status, 409);
    const del = await api().delete(`/api/categories/${created.body.category.id}`).set(auth(alice));
    assert.equal(del.status, 204);
  });
});

describe('Transactions, budgets and reports', () => {
  let food;
  let salary;

  before(async () => {
    const cats = (await api().get('/api/categories').set(auth(alice))).body.categories;
    food = cats.find((c) => c.name === 'Food & Dining').id;
    salary = cats.find((c) => c.name === 'Salary').id;
  });

  test('creates income and expense transactions', async () => {
    const inc = await api().post('/api/transactions').set(auth(alice))
      .send({ type: 'income', amount: 50000, category_id: salary, description: 'March salary', date: `${MONTH}-01` });
    assert.equal(inc.status, 201);
    assert.equal(inc.body.transaction.category_name, 'Salary');

    for (const [amt, d] of [[800, '05'], [1200, '12'], [500, '20']]) {
      const r = await api().post('/api/transactions').set(auth(alice))
        .send({ type: 'expense', amount: amt, category_id: food, description: 'Food', date: `${MONTH}-${d}` });
      assert.equal(r.status, 201);
    }
  });

  test('rejects invalid transaction payloads', async () => {
    const neg = await api().post('/api/transactions').set(auth(alice))
      .send({ type: 'expense', amount: -5, date: `${MONTH}-01` });
    assert.equal(neg.status, 400);
    const badDate = await api().post('/api/transactions').set(auth(alice))
      .send({ type: 'expense', amount: 5, date: '01/03/2026' });
    assert.equal(badDate.status, 400);
    const badType = await api().post('/api/transactions').set(auth(alice))
      .send({ type: 'gift', amount: 5, date: `${MONTH}-01` });
    assert.equal(badType.status, 400);
  });

  test('lists with filters and pagination', async () => {
    const all = await api().get('/api/transactions').query({ limit: 2 }).set(auth(alice));
    assert.equal(all.body.transactions.length, 2);
    assert.equal(all.body.pagination.total, 4);
    assert.equal(all.body.pagination.pages, 2);

    const expenses = await api().get('/api/transactions').query({ type: 'expense' }).set(auth(alice));
    assert.equal(expenses.body.pagination.total, 3);

    const ranged = await api().get('/api/transactions').query({ from: `${MONTH}-10`, to: `${MONTH}-25` }).set(auth(alice));
    assert.equal(ranged.body.pagination.total, 2);
  });

  test('updates and deletes a transaction', async () => {
    const created = await api().post('/api/transactions').set(auth(alice))
      .send({ type: 'expense', amount: 99, category_id: food, description: 'temp', date: `${MONTH}-28` });
    const id = created.body.transaction.id;
    const upd = await api().put(`/api/transactions/${id}`).set(auth(alice))
      .send({ type: 'expense', amount: 150, category_id: food, description: 'edited', date: `${MONTH}-28` });
    assert.equal(upd.status, 200);
    assert.equal(upd.body.transaction.amount, 150);
    const del = await api().delete(`/api/transactions/${id}`).set(auth(alice));
    assert.equal(del.status, 204);
    assert.equal((await api().delete(`/api/transactions/${id}`).set(auth(alice))).status, 404);
  });

  test("a user cannot see, edit or delete another user's data", async () => {
    const bobList = await api().get('/api/transactions').set(auth(bob));
    assert.equal(bobList.body.pagination.total, 0);

    const aliceTx = (await api().get('/api/transactions').set(auth(alice))).body.transactions[0];
    const del = await api().delete(`/api/transactions/${aliceTx.id}`).set(auth(bob));
    assert.equal(del.status, 404);

    const stolenCat = await api().post('/api/transactions').set(auth(bob))
      .send({ type: 'expense', amount: 10, category_id: food, date: `${MONTH}-01` });
    assert.equal(stolenCat.status, 400);
  });

  test('budget upsert tracks spending, remaining and status', async () => {
    const set = await api().post('/api/budgets').set(auth(alice)).send({ category_id: food, month: MONTH, limit_amount: 3000 });
    assert.equal(set.status, 201);
    let list = await api().get('/api/budgets').query({ month: MONTH }).set(auth(alice));
    assert.equal(list.body.budgets.length, 1);
    assert.equal(list.body.budgets[0].spent, 2500);
    assert.equal(list.body.budgets[0].remaining, 500);
    assert.equal(list.body.budgets[0].status, 'warning');

    // Upserting again updates rather than duplicating
    await api().post('/api/budgets').set(auth(alice)).send({ category_id: food, month: MONTH, limit_amount: 2000 });
    list = await api().get('/api/budgets').query({ month: MONTH }).set(auth(alice));
    assert.equal(list.body.budgets.length, 1);
    assert.equal(list.body.budgets[0].status, 'over');
  });

  test('monthly summary computes totals and category breakdown', async () => {
    const res = await api().get('/api/reports/summary').query({ month: MONTH }).set(auth(alice));
    assert.equal(res.status, 200);
    assert.equal(res.body.income, 50000);
    assert.equal(res.body.expense, 2500);
    assert.equal(res.body.balance, 47500);
    assert.equal(res.body.savings_rate, 95);
    assert.equal(res.body.by_category[0].name, 'Food & Dining');
    assert.equal(res.body.by_category[0].total, 2500);
  });

  test('trend returns six consecutive months, zero-filled', async () => {
    const res = await api().get('/api/reports/trend').query({ month: MONTH }).set(auth(alice));
    assert.equal(res.body.trend.length, 6);
    assert.deepEqual(res.body.trend.map((t) => t.month), ['2025-10', '2025-11', '2025-12', '2026-01', '2026-02', '2026-03']);
    assert.equal(res.body.trend[5].income, 50000);
    assert.equal(res.body.trend[0].income, 0);
  });

  test('report endpoints validate the month parameter', async () => {
    const res = await api().get('/api/reports/summary').query({ month: '2026-13' }).set(auth(alice));
    assert.equal(res.status, 400);
  });

  test('CSV export contains header and rows', async () => {
    const res = await api().get('/api/transactions/export.csv').set(auth(alice));
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'], /text\/csv/);
    assert.ok(res.text.startsWith('Date,Type,Category,Description,Amount'));
    assert.ok(res.text.includes('March salary'));
  });

  test('CSV export neutralises formula injection', async () => {
    await api().post('/api/transactions').set(auth(bob))
      .send({ type: 'expense', amount: 1, description: '=HYPERLINK("http://evil")', date: `${MONTH}-02` });
    const res = await api().get('/api/transactions/export.csv').set(auth(bob));
    assert.ok(res.text.includes(`"'=HYPERLINK`));
  });
});
