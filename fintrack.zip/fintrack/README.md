# 💰 FinTrack — Personal Finance & Budget Manager

A full-stack web application for tracking income and expenses, setting monthly category budgets and visualising spending habits.

**Stack:** React 18 (Vite) · Node.js / Express · SQLite · JWT authentication · Recharts · Docker · GitHub Actions

---

## Features

- **Authentication** — register / login with bcrypt-hashed passwords and JWT sessions
- **Transactions** — add, edit, delete, search, filter (type, category, date range) and paginate
- **Categories** — sensible defaults on sign-up plus custom categories with colours
- **Budgets** — monthly limit per category with live progress bars (OK / warning at 80% / over budget)
- **Dashboard** — income, expenses, balance, savings rate, spending-by-category donut chart and a 6-month trend chart
- **CSV export** of any filtered transaction list (with spreadsheet formula-injection protection)
- **Security** — Helmet headers, CORS allow-list, rate-limited auth routes, request validation (Zod), per-user data isolation
- **Quality** — automated API test suite, Dockerised deployment, CI pipeline

## Architecture

```mermaid
flowchart LR
    U[Browser<br/>React SPA] -- "HTTPS / JSON + Bearer JWT" --> A[Express REST API]
    A --> M[Middleware<br/>helmet · cors · rate-limit · auth · zod]
    M --> R[Route handlers<br/>auth · categories · transactions · budgets · reports]
    R --> D[(SQLite<br/>better-sqlite3)]
```

```
fintrack/
├── backend/
│   ├── src/
│   │   ├── app.js            # Express app factory (testable)
│   │   ├── server.js         # HTTP entry point
│   │   ├── db.js             # Schema + default categories
│   │   ├── config.js         # Environment config
│   │   ├── middleware/       # auth (JWT), validate (Zod), error handler
│   │   └── routes/           # auth, categories, transactions, budgets, reports
│   ├── scripts/seed.js       # Demo data generator
│   └── tests/api.test.js     # Automated API tests (node:test + supertest)
├── frontend/
│   └── src/
│       ├── pages/            # AuthPage, Dashboard, Transactions, Budgets, Categories
│       ├── components/       # Navbar, TransactionModal, shared UI
│       ├── context/          # AuthContext
│       └── api.js            # Fetch wrapper
├── docs/REPORT_GUIDE.md      # Chapter-by-chapter help for your project report
├── docker-compose.yml
└── .github/workflows/ci.yml
```

## Getting started

**Requirements:** Node.js 18+ (22 recommended) and npm.

```bash
# 1. Install everything
npm install                 # root helper (concurrently)
npm run install:all         # backend + frontend

# 2. Configure the backend
cp backend/.env.example backend/.env     # then edit JWT_SECRET

# 3. (Optional) load demo data: demo@fintrack.dev / Demo@1234
npm run seed

# 4. Run API (http://localhost:5000) and web app (http://localhost:5173) together
npm run dev
```

Or run them separately: `npm run dev --prefix backend` and `npm run dev --prefix frontend`.

> **First commit tip:** the first `npm install` creates `package-lock.json` files in `backend/` and `frontend/`. Commit them so everyone (and CI) gets identical dependency versions.

### Run the tests

```bash
npm test
```

The suite covers authentication, validation, CRUD, filtering and pagination, budget calculations, reports, CSV export and cross-user data isolation.

### Docker

```bash
cp .env.example .env        # set JWT_SECRET
docker compose up --build   # app on http://localhost:8080
docker compose exec backend npm run seed   # optional demo data
```

## API reference

All routes except `/api/auth/*` and `/api/health` require `Authorization: Bearer <token>`.

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Liveness check |
| POST | `/api/auth/register` | Create account → `{ token, user }` |
| POST | `/api/auth/login` | Log in → `{ token, user }` |
| GET | `/api/auth/me` | Current user |
| GET / POST | `/api/categories` | List / create categories |
| DELETE | `/api/categories/:id` | Delete a category |
| GET | `/api/transactions` | List — query: `type, category_id, from, to, q, page, limit` |
| POST | `/api/transactions` | Create transaction |
| PUT | `/api/transactions/:id` | Update transaction |
| DELETE | `/api/transactions/:id` | Delete transaction |
| GET | `/api/transactions/export.csv` | CSV download (same filters as list) |
| GET | `/api/budgets?month=YYYY-MM` | Budgets with `spent`, `remaining`, `status` |
| POST | `/api/budgets` | Create or update a budget (upsert per category + month) |
| DELETE | `/api/budgets/:id` | Remove a budget |
| GET | `/api/reports/summary?month=YYYY-MM` | Totals, savings rate, category breakdown |
| GET | `/api/reports/trend?month=YYYY-MM` | Six-month income vs expense trend |

Example:

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@fintrack.dev","password":"Demo@1234"}'
```

## Database design

```mermaid
erDiagram
    USERS ||--o{ CATEGORIES : owns
    USERS ||--o{ TRANSACTIONS : records
    USERS ||--o{ BUDGETS : sets
    CATEGORIES ||--o{ TRANSACTIONS : classifies
    CATEGORIES ||--o{ BUDGETS : limits

    USERS { int id PK; text name; text email UK; text password_hash; text created_at }
    CATEGORIES { int id PK; int user_id FK; text name; text color }
    TRANSACTIONS { int id PK; int user_id FK; int category_id FK; text type; real amount; text description; text date }
    BUDGETS { int id PK; int user_id FK; int category_id FK; text month; real limit_amount }
```

## Security notes

- Passwords are hashed with bcrypt (cost 10) and never returned by the API.
- Every query is scoped by the authenticated user's id; users can't read or modify each other's data.
- All inputs are validated with Zod; SQL uses prepared statements throughout.
- Set a strong `JWT_SECRET` in production — the server refuses to start in production without one.
- For production, serve over HTTPS and consider moving the token to an httpOnly cookie.

## Ideas for extending the project

Recurring transactions, multi-currency support, receipt uploads, email budget alerts, PostgreSQL for multi-instance deployment, refresh tokens, and a React Native mobile client.

## License

MIT
